package com.sun.syndication.unittest;

/**
 *
 * <p>
 * @author Alejandro Abdelnur
 *
 */
public class TestOpsRSS20 extends FeedOpsTest {

    public TestOpsRSS20() {
        super("rss_2.0");
    }

}
