/*
 * Created on Jun 24, 2004
 *
 */
package com.sun.syndication.unittest;

import com.sun.syndication.feed.synd.SyndEntry;
import com.sun.syndication.feed.synd.SyndCategory;

import java.util.List;

/**
 * @author pat
 *
 */
public class TestSyndFeedRSS092 extends TestSyndFeedRSS091N {

    public TestSyndFeedRSS092() {
        super("rss_0.92");
    }

    protected TestSyndFeedRSS092(String type) {
        super(type);
    }

    protected TestSyndFeedRSS092(String feedType,String feedFileName) {
        super(feedType,feedFileName);
    }

    protected void _testItem(int i) throws Exception {
        super._testItem(i);
        List items = getCachedSyndFeed().getEntries();
        SyndEntry entry = (SyndEntry) items.get(i);

        assertProperty(entry.getTitle(),"channel.item["+i+"].title");
        assertProperty(entry.getLink(),"channel.item["+i+"].link");
        assertProperty(entry.getDescription().getValue(),"channel.item["+i+"].description");
        _testCategories(entry.getCategories(),"channel.item["+i+"]");
    }

    protected void _testCategories(List cats,String prefix) throws Exception {
        _testCategory((SyndCategory)cats.get(0),prefix,0);
        _testCategory((SyndCategory)cats.get(1),prefix,1);
    }

    protected void _testCategory(SyndCategory category,String prefix,int i) throws Exception {
        assertProperty(category.getTaxonomyUri(),prefix+".category["+i+"]^domain");
        assertProperty(category.getName(),prefix+".category["+i+"]");
    }

}
