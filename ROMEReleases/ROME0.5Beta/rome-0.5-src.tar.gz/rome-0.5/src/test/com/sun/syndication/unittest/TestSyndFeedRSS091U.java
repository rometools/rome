/*
 * Created on Jun 24, 2004
 *
 */
package com.sun.syndication.unittest;

/**
 * @author pat
 *
 */
public class TestSyndFeedRSS091U extends TestSyndFeedRSS091N {

    public TestSyndFeedRSS091U() {
        super("rss_0.91U", "rss_0.91U.xml");
    }

}
