package com.sun.syndication.unittest;

/**
 *
 * <p>
 * @author Alejandro Abdelnur
 *
 */
public class TestOpsRSS10 extends FeedOpsTest {

    public TestOpsRSS10() {
        super("rss_1.0");
    }

}
