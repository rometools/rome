pushd ../..
ant clean dist
cp dist/rome-propono-0.6/lib/rome-propono-0.6.jar lib
popd
ant clean dist
rm -rf ~/tomcat/webapps/sample-atomserver* ~/tomcat/work/*
cp dist/sample-atomserver.war ~/tomcat/webapps
restartcat

