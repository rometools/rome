/*   
 * Copyright 2007 Sun Microsystems, Inc.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 
package com.sun.syndication.propono.atom.client;

import com.sun.syndication.propono.utils.ProponoException;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import com.sun.syndication.io.impl.Atom10Parser;


/**
 * Creates AtomService or ClientCollection based on username, password and 
 * end-point URI of Atom protocol service.
 */
public class AtomClientFactory {
    
    static {
        Atom10Parser.setResolveURIs(true);
    }
    
    /**
     * Create AtomService by reading service doc from Atom Server.
     */
    public static ClientAtomService getAtomService(
            String uri, String username, String password) throws ProponoException {
        return new ClientAtomService(uri, username, password);
    }     
    
    /**
     * Create ClientCollection bound to URI.
     */
    public static ClientCollection getCollection(
            String uri, String username, String password) throws ProponoException {
        return new ClientCollection(uri, username, password);
    } 
    
    /**
     * Create AtomService by reading service doc from GData Atom Server.
     * @param uri      URI of Atom service document
     * @param email    Gmail email address, used as username
     * @param password Password for Gmail email account
     * @param service  Type of service, e.g. 'blogger'
     */
    public static ClientAtomService getGDataAtomService(
            String uri, String email, String password, String service) throws ProponoException {
        String authString = getGDataAuthString(email, password, service);
        return new ClientAtomService(uri, authString);
    }     
    
    /**
     * Create ClientCollection via collection URI from GData Atom Server.
     * @param uri      URI of collection
     * @param email    Gmail email address, used as username
     * @param password Password for Gmail email account
     * @param service  Type of service, e.g. 'blogger'
     */
    public static ClientCollection getGDataCollection(
            String uri, String email, String password, String service) throws ProponoException {
         String authString = getGDataAuthString(email, password, service);
         return new ClientCollection(uri, authString);
    } 
    
    /** Obtain GData auth string from Google */
    private static String getGDataAuthString(
        String email, String password, String service) throws ProponoException {
        try {
            HttpClient httpClient = new HttpClient();           
            PostMethod method = new PostMethod("https://www.google.com/accounts/ClientLogin");  
            NameValuePair[] data = {
              new NameValuePair("Email", email),
              new NameValuePair("Passwd", password),
              new NameValuePair("accountType", "GOOGLE"),
              new NameValuePair("service", service),
              new NameValuePair("source", "ROME Propono Atompub Client")
            };
            method.setRequestBody(data);
            httpClient.executeMethod(method);  

            String responseBody = method.getResponseBodyAsString();
            int authIndex = responseBody.indexOf("Auth=");

            return "GoogleLogin auth=" + responseBody.trim().substring(authIndex + 5);
            
        } catch (Throwable t) {
            throw new ProponoException("ERROR obtaining Google authentication string", t);
        }        
    }
}
