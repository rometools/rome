package com.sun.syndication.unittest;

/**
 *
 * <p>
 * @author Alejandro Abdelnur
 *
 */
public class TestOpsRSS093 extends FeedOpsTest {

    public TestOpsRSS093() {
        super("rss_0.93");
    }

}
