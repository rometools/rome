/*   
 * Copyright 2007 Sun Microsystems, Inc.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 
package com.sun.syndication.propono.atom.server.impl;

import org.apache.commons.codec.binary.Base64;
import com.sun.syndication.propono.atom.server.AtomHandler;
import com.sun.syndication.propono.atom.server.AtomException;
import com.sun.syndication.propono.atom.server.AtomServlet;
import com.sun.syndication.feed.atom.Entry;
import com.sun.syndication.feed.atom.Feed;
import com.sun.syndication.propono.atom.common.AtomService;
import java.io.File;
import java.io.InputStream;
import java.util.StringTokenizer;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import javax.servlet.http.HttpServletRequest;


/**
 * File-based {@link com.sun.syndication.propono.atom.server.AtomHandler}
 * implementation that stores entries and media-entries to disk. Implemented 
 * using {@link com.sun.syndication.propono.atom.server.impl.FileBasedAtomService}.
 */
public class FileBasedAtomHandler implements AtomHandler {

    private static Log log =
            LogFactory.getFactory().getInstance(FileBasedAtomHandler.class);
    
    private static String fileStoreDir = null;

    private String userName = null;
    private String atomProtocolURL = null;
    private String contextURL = null;    
    private String uploadurl = null;
    
    private FileBasedAtomService service = null;
    
    /**
     * Construct handler to handle one request.
     * @param req Request to be handled.
     */
    public FileBasedAtomHandler( HttpServletRequest req ) {     
        this(req, AtomServlet.getContextDirPath());
    } 
    
    /**
     * Contruct handler for one request, using specified file storage directory.
     * @param req       Request to be handled.
     * @param uploaddir File storage upload dir.
     */
    public FileBasedAtomHandler(HttpServletRequest req, String uploaddir) {
        
        userName = authenticateBASIC(req);        
        
        atomProtocolURL = req.getScheme() + "://" + req.getServerName() + ":" 
                + req.getServerPort()  + req.getContextPath() + req.getServletPath();
        
        contextURL = req.getScheme() + "://" + req.getServerName() + ":" 
                + req.getServerPort()  + req.getContextPath();
    
        try {
            service = new FileBasedAtomService(userName, uploaddir, atomProtocolURL);
            
        } catch (Throwable t) {
            throw new RuntimeException("ERRLR creating FileBasedAtomService");
        }
    }
    
    /** 
     * Method used for validating user. Developers can overwrite this method 
     * and use credentials stored in Database or LDAP to confirm if the user is 
     * allowed to access this service.
     * @param login    user submitted login id
     * @param password user submitted password 
     */
    public boolean validateUser(String login, String password) {
        return true;
    }
    
    /**
     * Get username of authenticated user
     * @return User name.
     */
    public String getAuthenticatedUsername() {
        // For now return userName as the login id entered for authorization
        return userName;
    }
    
    /**
     * Get base URI of Atom protocol implementation.
     * @return Base URI of Atom protocol implemenation.
     */
    public String getAtomProtocolURL( ) {
        if ( atomProtocolURL == null ) {
            return "app";
        } else {
            return  atomProtocolURL;
        }
    }
    
    /**
     * Return introspection document
     * @throws com.sun.syndication.propono.atom.server.AtomException Unexpected exception.
     * @return AtomService object with workspaces and collections.
     */
    public AtomService getIntrospection() throws AtomException {               
        return service;
    }
    
    
    /**
     * Get collection specified by pathinfo.
     * @param pathInfo Path info from Servlet request.
     * @return ROME feed representing collection.
     * @throws com.sun.syndication.propono.atom.server.AtomException Invalid collection or other exception.
     */
    public Feed getCollection(String[] pathInfo) throws AtomException {
        String handle = pathInfo[0];
        String collection = pathInfo[1];
        FileBasedCollection col = service.findCollectionByHandle(handle, collection);
        return col.getFeedDocument();        
    }
    
    /**
     * Create a new entry specified by pathInfo and posted entry. We save the 
     * submitted Atom entry verbatim, but we do set the id and reset the update
     * time.  
     *
     * @param entry Entry to be added to collection.
     * @param pathInfo Path info from Servlet request.
     * @throws com.sun.syndication.propono.atom.server.AtomException On invalid collection or other error.
     * @return Entry as represented on server.
     */
    public Entry postEntry(String[] pathInfo, Entry entry) throws AtomException {
        
        String handle = pathInfo[0];
        String collection = pathInfo[1];
        FileBasedCollection col = service.findCollectionByHandle(handle, collection);
        try {
            return col.addEntry(entry);
            
        } catch (Exception fe) {
            fe.printStackTrace();
            throw new AtomException( fe );
        }
    }
    
    /**
     * Get entry specified by pathInfo.
     * @param pathInfo Path info portion of URL
     * @throws com.sun.syndication.propono.atom.server.AtomException On invalid pathinfo or other error.
     * @return ROME Entry object.
     */
    public Entry getEntry(String[] pathInfo) throws AtomException {
        String handle = pathInfo[0];
        String collection = pathInfo[1];
        String fileName = pathInfo[2];
        FileBasedCollection col = service.findCollectionByHandle(handle, collection);
        try {              
            return col.getEntry(fileName);
                
        } catch (Exception re) {
            if (re instanceof AtomException) throw (AtomException)re;
            throw new AtomException("ERROR: getting entry", re);
        }
    }
    
    /**
     * Update entry specified by pathInfo and posted entry.
     * 
     * @param entry 
     * @param pathInfo Path info portion of URL
     * @throws com.sun.syndication.propono.atom.server.AtomException 
     */
    public Entry putEntry(String[] pathInfo, Entry entry) throws AtomException {
        String handle = pathInfo[0];
        String collection = pathInfo[1];
        String fileName = pathInfo[2];
        FileBasedCollection col = service.findCollectionByHandle(handle, collection);
        try {            
            return col.updateEntry(entry, fileName);
            
        } catch ( Exception fe ) {
            throw new AtomException( fe );
        }
    }
    
    
    /**
     * Delete entry specified by pathInfo.
     * @param pathInfo Path info portion of URL
     */
    public void deleteEntry(String[] pathInfo) throws AtomException {
        String handle = pathInfo[0];
        String collection = pathInfo[1];
        String fileName = pathInfo[2];
        FileBasedCollection col = service.findCollectionByHandle(handle, collection);
        try {
            col.deleteEntry(fileName); 

        } catch (Exception e) {
            String msg = "ERROR in atom.deleteResource";
            log.error(msg,e);
            throw new AtomException(msg);
        }
    }
    
    /**
     * Create a new media-link entry.
     * @param pathInfo Path info portion of URL
     * @param contentType MIME type of uploaded content
     * @param is Input Stream of Binary data representing uploaded content
     */
    public Entry postMedia(
            String[] pathInfo, String title, String slug, String contentType, InputStream is) throws AtomException {
        
        try {
            File tempFile = null;
            String handle = pathInfo[0];
            String collection = pathInfo[1];
            FileBasedCollection col = service.findCollectionByHandle(handle, collection);
            try {
                return col.addMediaEntry(title, slug, contentType, is);

            } catch (Exception e) {
                e.printStackTrace();
                String msg = "ERROR reading posted file";
                log.error(msg,e);
                throw new AtomException(msg, e);
            } finally {
                if (tempFile != null) tempFile.delete();
            }
            
        } catch (Exception re) {
            throw new AtomException("ERROR: posting media");
        }
   }
    
    /**
     * Update the media file part of a media-link entry.
     * @param pathInfo Path info portion of URL
     * Assuming pathInfo of form /user-name/resource/name
     */
    public Entry putMedia(
            String[] pathInfo, String contentType, InputStream is) throws AtomException {
        
        String handle = pathInfo[0];
        String collection = pathInfo[1];
        String fileName = pathInfo[2];
        FileBasedCollection col = service.findCollectionByHandle(handle, collection);
        try {
            return col.updateMediaEntry(fileName, contentType, is);
            
        } catch (Exception re) {
            throw new AtomException("ERROR: posting media");
        }
    }
    
    /**
     * Return true if specified pathinfo represents URI of introspection doc.
     */
    public boolean isIntrospectionURI(String [] pathInfo) {        
        if (pathInfo.length==0) return true;
        return false;
    }
    
    /**
     * Return true if specified pathinfo represents URI of a collection.
     */
    public boolean isCollectionURI(String [] pathInfo) {
        // workspace/collection-plural
        // if length is 2 and points to a valid collection then YES
        if (pathInfo.length == 2) {
            String handle     = pathInfo[0];
            String collection = pathInfo[1];
            if (service.findCollectionByHandle(handle, collection) != null) {
                return true;
            }
        }
        return false;
        
    }
    
    /**
     * Return true if specified pathinfo represents URI of an Atom entry.
     */
    public boolean isEntryURI(String[] pathInfo) {
        // workspace/collection-singular/fsid
        // if length is 3 and points to a valid collection then YES
        if (pathInfo.length == 3) {
            String handle     = pathInfo[0];
            String collection = pathInfo[1];
            if (service.findCollectionByHandle(handle, collection) != null) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Return true if specified pathinfo represents media-edit URI.
     */
    public boolean isMediaEditURI(String[] pathInfo) {
        // workspace/collection-singular/fsid/media/fsid
        // if length is 5, points to a valid collection and fsid is mentioned twice then YES!
        if (pathInfo.length == 5) {
            String handle     = pathInfo[0];
            String collection = pathInfo[1];
            String fsid1      = pathInfo[2];
            String media      = pathInfo[3];
            String fsid2      = pathInfo[4];
            if (service.findCollectionByHandle(handle, collection) != null  
                    && media.equals("media") && fsid1.equals(fsid2)) {
                return true;
            }
        }
        return false;
        
    }
    
    /**
     * BASIC authentication.
     */
    public String authenticateBASIC(HttpServletRequest request) {
        boolean valid = false;
        String userID = null;
        String password = null;
        try {
            String authHeader = request.getHeader("Authorization");
            if (authHeader != null) {
                StringTokenizer st = new StringTokenizer(authHeader);
                if (st.hasMoreTokens()) {
                    String basic = st.nextToken();
                    if (basic.equalsIgnoreCase("Basic")) {
                        String credentials = st.nextToken();
                        String userPass = new String(Base64.decodeBase64(credentials.getBytes()));
                        int p = userPass.indexOf(":");
                        if (p != -1) {
                            userID = userPass.substring(0, p);
                            password = userPass.substring(p+1);
                            
                            //  Validate the User.
                            valid = validateUser( userID, password );
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.debug(e);
        }
        if (valid) {
            //For now assume userID as userName
            return userID;
        }
        return null;
    }
}
