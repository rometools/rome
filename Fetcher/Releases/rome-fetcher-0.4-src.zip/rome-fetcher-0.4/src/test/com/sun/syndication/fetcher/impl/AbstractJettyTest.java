package com.sun.syndication.fetcher.impl;

import java.net.URL;

import junit.framework.TestCase;

import org.mortbay.http.HttpContext;
import org.mortbay.http.HttpServer;
import org.mortbay.http.SocketListener;
import org.mortbay.jetty.servlet.ServletHandler;

import com.sun.syndication.feed.synd.SyndFeed;
import com.sun.syndication.fetcher.FeedFetcher;
import com.sun.syndication.fetcher.FetcherEvent;
import com.sun.syndication.fetcher.FetcherException;
import com.sun.syndication.fetcher.FetcherListener;

/**
 * @author nl
 */
public abstract class AbstractJettyTest extends TestCase {

	private HttpServer server;
	
	/**
	 * @param s
	 */
	public AbstractJettyTest(String s) {
		super(s);
	}

	protected HttpServer getServer() {
		return server;
	}

	protected abstract FeedFetcher getFeedFetcher();
	
	protected abstract FeedFetcher getFeedFetcher(FeedFetcherCache cache);
	
	/**
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		// Create the server
		if (server != null) {
			server.stop();
			server = null;
		}
		server = new HttpServer();
	
		// Create a port listener
		SocketListener listener=new SocketListener();
		listener.setPort(8080);
		server.addListener(listener);
	
		HttpContext context = new HttpContext();
		context.setContextPath("/rome/*");
		server.addContext(context);
	
	
		ServletHandler servlets = new ServletHandler();
		context.addHandler(servlets);
	
		servlets.addServlet("FetcherTestServlet","/FetcherTestServlet/*","com.sun.syndication.fetcher.impl.FetcherTestServlet");
	
		server.start();
	}

	/**
	 * @see junit.framework.TestCase#tearDown()
	 */
	protected void tearDown() throws Exception {
		if (server != null) {
			server.stop();
			server.destroy();
			server = null;
		}
	}

	class FetcherEventListenerImpl implements FetcherListener {
		boolean polled = false;
		boolean retrieved = false;
		boolean unchanged = false;

		public void reset() {
			polled = false;
			retrieved = false;
			unchanged = false;
		}

		/**
		 * @see com.sun.syndication.fetcher.FetcherListener#fetcherEvent(com.sun.syndication.fetcher.FetcherEvent)
		 */
		public void fetcherEvent(FetcherEvent event) {
			String eventType = event.getEventType();
			if (FetcherEvent.EVENT_TYPE_FEED_POLLED.equals(eventType)) {
				System.err.println("\tEVENT: Feed Polled. URL = " + event.getUrlString());
				polled = true;
			} else if (FetcherEvent.EVENT_TYPE_FEED_RETRIEVED.equals(eventType)) {
				System.err.println("\tEVENT: Feed Retrieved. URL = " + event.getUrlString());
				retrieved = true;
			} else if (FetcherEvent.EVENT_TYPE_FEED_UNCHANGED.equals(eventType)) {
				System.err.println("\tEVENT: Feed Unchanged. URL = " + event.getUrlString());
				unchanged = true;
			}
		}
	}

	public void testRetrieveFeed() {
		FeedFetcher feedFetcher = getFeedFetcher();
		try {
			SyndFeed feed = feedFetcher.retrieveFeed(new URL("http://localhost:8080/rome/FetcherTestServlet/"));
			assertNotNull(feed);
			assertEquals("atom_0.3.feed.title", feed.getTitle());
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.getMessage());
		}
	}

	/**
	 * Test getting a feed via a http 301 redirect
	 *
	 */
	public void testRetrieveRedirectedFeed() {
		FeedFetcher feedFetcher = getFeedFetcher();
		try {
			SyndFeed feed = feedFetcher.retrieveFeed(new URL("http://localhost:8080/rome/FetcherTestServlet?redirect=TRUE"));
			assertEquals("atom_0.3.feed.title", feed.getTitle());
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.getMessage());
		}
	}

	/**
	 * Test error handling
	 *
	 */
	public void testErrorHandling() {
		FeedFetcher feedFetcher = getFeedFetcher();
		try {
			SyndFeed feed = feedFetcher.retrieveFeed(new URL("http://localhost:8080/rome/FetcherTestServlet?error=404"));
			fail("4xx error handling did not work correctly");
		} catch (FetcherException e) {
			// expect this exception
			assertEquals(404, e.getResponseCode());
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.getMessage());
		}
	
		try {
			SyndFeed feed = feedFetcher.retrieveFeed(new URL("http://localhost:8080/rome/FetcherTestServlet?error=500"));
			fail("5xx error handling did not work correctly");
		} catch (FetcherException e) {
			// expect this exception
			assertEquals(500, e.getResponseCode());
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.getMessage());
		}
	}

	public void testUserAgent() {
		FeedFetcher feedFetcher = getFeedFetcher();
		//System.out.println(feedFetcher.getUserAgent());
		//System.out.println(System.getProperty("rome.fetcher.version", "UNKNOWN"));
		assertEquals("Rome Client (http://rome.dev.java.net/) Ver: " + System.getProperty("rome.fetcher.version", "UNKNOWN"), feedFetcher.getUserAgent());
	}

	/**
	 * Test events fired when there is no cache in use
	 *
	 */
	public void testFetchEvents() {
		FeedFetcher feedFetcher = getFeedFetcher();
		FetcherEventListenerImpl listener = new FetcherEventListenerImpl();
		feedFetcher.addFetcherEventListener(listener);
		try {
			SyndFeed feed = feedFetcher.retrieveFeed(new URL("http://localhost:8080/rome/FetcherTestServlet/"));
			assertTrue(listener.polled);
			assertTrue(listener.retrieved);
			assertFalse(listener.unchanged);
			listener.reset();
	
			// since there is no cache, the events fired should be exactly the same if
			// we re-retrieve the feed
			feed = feedFetcher.retrieveFeed(new URL("http://localhost:8080/rome/FetcherTestServlet/"));
			assertTrue(listener.polled);
			assertTrue(listener.retrieved);
			assertFalse(listener.unchanged);
			listener.reset();
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.getMessage());
		}
	}

	/**
	 * Test events fired when there is a cache in use
	 *
	 */
	public void testFetchEventsWithCache() {
		FeedFetcherCache feedInfoCache = new HashMapFeedInfoCache();
		FeedFetcher feedFetcher = getFeedFetcher(feedInfoCache);
		FetcherEventListenerImpl listener = new FetcherEventListenerImpl();
		feedFetcher.addFetcherEventListener(listener);
		try {
			SyndFeed feed = feedFetcher.retrieveFeed(new URL("http://localhost:8080/rome/FetcherTestServlet/"));
			assertNotNull(feed);
			assertTrue(listener.polled);
			assertTrue(listener.retrieved);
			assertFalse(listener.unchanged);
			listener.reset();
	
			// Since the feed is cached, the second request should not
			// actually retrieve the feed
			feed = feedFetcher.retrieveFeed(new URL("http://localhost:8080/rome/FetcherTestServlet/"));
			assertNotNull(feed);
			assertTrue(listener.polled);
			assertFalse(listener.retrieved);
			assertTrue(listener.unchanged);
			listener.reset();
	
			// now simulate getting the feed after it has changed
			feed = feedFetcher.retrieveFeed(new URL("http://localhost:8080/rome/FetcherTestServlet?refreshfeed=TRUE"));
			assertNotNull(feed);
			assertTrue(listener.polled);
			assertTrue(listener.retrieved);
			assertFalse(listener.unchanged);
			listener.reset();
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.getMessage());
		}
	}
	
	/**
	 * Test handling of GZipped feed
	 *
	 */
	public void testGZippedFeed() {
		FeedFetcher feedFetcher = getFeedFetcher();
		try {
			SyndFeed feed = feedFetcher.retrieveFeed(new URL("http://localhost:8080/rome/FetcherTestServlet?gzipfeed=TRUE"));
			assertNotNull(feed);
			assertEquals("atom_0.3.feed.title", feed.getTitle());
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.getMessage());
		}	    
	}
	
	
}
