package com.sun.syndication.fetcher.impl;

import com.sun.syndication.fetcher.FeedFetcher;

/**
 * @author Nick Lothian
 */
public class HttpClientFeedFetcherTest extends AbstractJettyTest {

	public HttpClientFeedFetcherTest(String s) {
		super(s);
	}
	
	/**
	 * @see com.sun.syndication.fetcher.impl.AbstractJettyTest#getFeedFetcher()
	 */
	protected FeedFetcher getFeedFetcher() {		
		return new HttpClientFeedFetcher();
	}
	
	protected FeedFetcher getFeedFetcher(FeedFetcherCache cache) {
		return new HttpClientFeedFetcher(cache);
	}
	
	
	
}
