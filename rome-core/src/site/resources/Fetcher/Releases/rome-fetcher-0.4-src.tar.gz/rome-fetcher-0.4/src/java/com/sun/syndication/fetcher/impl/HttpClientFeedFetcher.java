/*
 * Copyright 2004 Sun Microsystems, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package com.sun.syndication.fetcher.impl;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.zip.GZIPInputStream;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.methods.GetMethod;

import com.sun.syndication.feed.synd.SyndFeed;
import com.sun.syndication.fetcher.FetcherEvent;
import com.sun.syndication.fetcher.FetcherException;
import com.sun.syndication.io.FeedException;
import com.sun.syndication.io.SyndFeedInput;

/**
 * @author Nick Lothian
 */
public class HttpClientFeedFetcher extends AbstractFeedFetcher {
	private FeedFetcherCache feedInfoCache;
	
	public HttpClientFeedFetcher() {
		super();
	}

	
	/**
	 * @param cache
	 */
	public HttpClientFeedFetcher(FeedFetcherCache cache) {
		this();
		this.feedInfoCache = cache;
	}

	/**
	 * @see com.sun.syndication.fetcher.FeedFetcher#retrieveFeed(java.net.URL)
	 */
	public SyndFeed retrieveFeed(URL feedUrl) throws IllegalArgumentException, IOException, FeedException, FetcherException {
		if (feedUrl == null) {
			throw new IllegalArgumentException("null is not a valid URL");
		}
		// TODO Fix this
		//System.setProperty("org.apache.commons.logging.Log", "org.apache.commons.logging.impl.SimpleLog");
		HttpClient client = new HttpClient();		
		
		
		System.setProperty("httpclient.useragent", getUserAgent());
		String urlStr = feedUrl.toString();
		if (feedInfoCache != null) {
			// get the feed info from the cache
			SyndFeedInfo syndFeedInfo = feedInfoCache.getFeedInfo(feedUrl);
			if (syndFeedInfo == null) {
				// this feed is not in the cache
								
				// retrieve feed
				HttpMethod method = new GetMethod(urlStr);
				try {
					syndFeedInfo = new SyndFeedInfo();
					
					// this may be different to feedURL because of 3XX redirects
					syndFeedInfo.setUrl(new URL(urlStr));
					syndFeedInfo.setId(feedUrl.toString());
					
					SyndFeed feed = retrieveFeed(null, client, urlStr, method);					
					
					syndFeedInfo.setSyndFeed(feed);
					
					Header lastModifiedHeader = method.getResponseHeader("Last-Modified");
					if (lastModifiedHeader != null) {
					    syndFeedInfo.setLastModified(lastModifiedHeader.getValue());
					}
					
					Header eTagHeader = method.getResponseHeader("ETag");
					if (eTagHeader != null) {
					    syndFeedInfo.setETag(eTagHeader.getValue());
					}
					
					feedInfoCache.setFeedInfo(new URL(urlStr), syndFeedInfo);
										
					return feed;
				} finally {
					method.releaseConnection();
				}
			} else {
				// feed is in cache
				HttpMethod method = new GetMethod(urlStr);
				try {
				    
				    SyndFeed feed = retrieveFeed(syndFeedInfo, client, urlStr, method);
				    
				    return feed;

				} finally {
					method.releaseConnection();
				}				    
			}		
		} else {
		    // cache is not in use		    
			HttpMethod method = new GetMethod(urlStr);
			try {
				return retrieveFeed(null, client, urlStr, method);
			} finally {
				method.releaseConnection();
			}
		}
	}


	/**
	 * @param client
	 * @param urlStr
	 * @param method
	 * @return
	 * @throws IOException
	 * @throws HttpException
	 * @throws FetcherException
	 * @throws FeedException
	 */
	private SyndFeed retrieveFeed(SyndFeedInfo syndFeedInfo, HttpClient client, String urlStr, HttpMethod method) throws IOException, HttpException, FetcherException, FeedException {
	    if (syndFeedInfo != null) {
		    method.setRequestHeader("If-None-Match", syndFeedInfo.getETag());
		    
		    if (syndFeedInfo.getLastModified() instanceof String) {
		        method.setRequestHeader("If-Modified-Since", (String)syndFeedInfo.getLastModified());
		    }
	    }
	    
	    method.setFollowRedirects(true);			
		
		int statusCode = client.executeMethod(method);
		fireEvent(FetcherEvent.EVENT_TYPE_FEED_POLLED, urlStr);
		
		handleErrorCodes(statusCode);
		if (statusCode == HttpURLConnection.HTTP_NOT_MODIFIED && syndFeedInfo != null) {
		    fireEvent(FetcherEvent.EVENT_TYPE_FEED_UNCHANGED, urlStr);
		    return syndFeedInfo.getSyndFeed();
		}
		
		fireEvent(FetcherEvent.EVENT_TYPE_FEED_RETRIEVED, urlStr);			
		
		InputStream stream = null;
		if ((method.getResponseHeader("Content-Encoding") != null) && ("gzip".equals(method.getResponseHeader("Content-Encoding").getValue()))) {		
		    stream = new GZIPInputStream(method.getResponseBodyAsStream());
		} else {
		    stream = method.getResponseBodyAsStream();
		}		
		try {				
			InputStreamReader reader = new InputStreamReader(stream);
			SyndFeedInput input = new SyndFeedInput();
			SyndFeed feed = input.build(reader);
							
			return feed;
			
		} finally {
		    if (stream != null) {
		        stream.close();
		    }
			
		}
	}
}
