package com.sun.syndication.fetcher;

import java.util.EventObject;

/**
 * @author nl
 *
 */
public class FetcherEvent extends EventObject {
	public static final String EVENT_TYPE_FEED_POLLED = "FEED_POLLED";
	public static final String EVENT_TYPE_FEED_RETRIEVED = "FEED_RETRIEVED";
	public static final String EVENT_TYPE_FEED_UNCHANGED = "FEED_UNCHANGED";
	
	private String eventType;
	private String urlString;

	public FetcherEvent(Object source) {
		super(source);
	}


	public FetcherEvent(Object source, String urlStr, String eventType) {
		this(source);
		setUrlString(urlStr);
		setEventType(eventType);
	}	

	/**
	 * @return Returns the eventType.
	 */
	public String getEventType() {
		return eventType;
	}
	/**
	 * @param eventType The eventType to set.
	 */
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	/**
	 * @return Returns the urlString.
	 */
	public String getUrlString() {
		return urlString;
	}
	/**
	 * @param urlString The urlString to set.
	 */
	public void setUrlString(String urlString) {
		this.urlString = urlString;
	}
}
