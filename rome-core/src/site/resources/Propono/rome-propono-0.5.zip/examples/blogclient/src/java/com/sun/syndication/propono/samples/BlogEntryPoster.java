/*
 * Copyright 2007 Sun Microsystems, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.sun.syndication.propono.samples;

import com.sun.syndication.propono.blogclient.Blog;
import com.sun.syndication.propono.blogclient.BlogConnection;
import com.sun.syndication.propono.blogclient.BlogConnectionFactory;
import com.sun.syndication.propono.blogclient.BlogEntry;
import com.sun.syndication.propono.blogclient.BlogEntry.Content;

/**
 * Simple Blog client posts entry given username, password, title, HTML text and URI.
 */
public class BlogEntryPoster {
    
    public static void main(String[] args) throws Exception {               
        if (args.length < 5) {
            System.out.println("USAGE: entryposter <username> <password> <title> <htmltext> <uri>");
            System.exit(-1);
        }
        String username = args[0];
        String password = args[1];
        String title    = args[2];
        String htmltext = args[3];
        String uri      = args[4];

        BlogConnection conn = 
            BlogConnectionFactory.getBlogConnection("metaweblog", uri, username, password);
                
        Blog blog = (Blog)conn.getBlogs().get(0);
        BlogEntry entry = blog.newEntry();
        entry.setTitle(title);
        entry.setContent(new Content(htmltext));
        entry.save();
    }
}
