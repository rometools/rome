/*
 * Copyright 2004 Sun Microsystems, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
package com.sun.syndication.io.impl;

import java.io.UnsupportedEncodingException;

/**
 * Encodes/decodes String values into/from a base 64 String.
 * <p>
 * It uses Jakarta commons codec Base64 class.
 * <p>
 * @author Alejandro Abdelnur
 *
 */
public class Base64 {

    /**
     * Encodes a String into a base 64 String. The resulting encoding is chunked at 76 bytes.
     * <p>
     * @param s String to encode.
     * @param encoding the encoding of the original String, <b>null</b> indicates platform's default.
     * @return encoded string.
     * @throws java.io.UnsupportedEncodingException thrown if the given encoding is not supported.
     *
     */
    public static String encode(String s,String encoding) throws UnsupportedEncodingException {
        if (s==null) {
            throw new IllegalArgumentException("Cannot encode null");
        }
        byte[] sBytes = (encoding!=null) ? s.getBytes(encoding) : s.getBytes();
        sBytes = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(sBytes);
        s = new String(sBytes); // no need to specify encoding as it's all 7bits
        return s;
    }

    /**
     * Decodes a base 64 String into a String.
     * <p>
     * @param s String to decode.
     * @param encoding the encoding of the String being decoded, <b>null</b> indicates platform's default.
     * @return encoded string.
     * @throws java.io.UnsupportedEncodingException thrown if the given encoding is not supported.
     *
     */
    public static String decode(String s,String encoding) throws UnsupportedEncodingException {
        if (s==null) {
            throw new IllegalArgumentException("Cannot decode null");
        }
        byte[] sBytes = s.getBytes();  // no need to specify encoding as it's all 7bits (it should be)
        sBytes = org.apache.commons.codec.binary.Base64.decodeBase64(sBytes);
        s = (encoding!=null) ? new String(sBytes,encoding) : new String(sBytes);
        return s;
    }

}

