/*
 * Created on Jun 24, 2004
 *
 */
package com.sun.syndication.unittest;

/**
 * @author pat
 *
 */
public class TestSyndFeedRSS092 extends SyndFeedTest {

	public TestSyndFeedRSS092() {
		super("rss_0.92");
	}
}
