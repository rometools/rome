/*
 * Created on Jun 24, 2004
 *
 */
package com.sun.syndication.unittest;

/**
 * @author pat
 *
 */
public class TestSyndFeedRSS093 extends SyndFeedTest {

	public TestSyndFeedRSS093() {
		super("rss_0.93");
	}
}
