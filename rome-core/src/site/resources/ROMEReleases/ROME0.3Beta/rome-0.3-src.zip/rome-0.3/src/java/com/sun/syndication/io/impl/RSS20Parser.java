/*
 * Copyright 2004 Sun Microsystems, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
package com.sun.syndication.io.impl;

import com.sun.syndication.feed.rss.Description;
import com.sun.syndication.feed.rss.Channel;
import com.sun.syndication.feed.rss.Item;
import com.sun.syndication.feed.WireFeed;
import org.jdom.Element;

import java.util.List;

/**
 */
public class RSS20Parser extends RSS094Parser {

    /**
     * rss_2.0.feed.ModuleParser.classes=  [className] ...
     *
     */
    public static final String FEED_MODULE_PARSERS_KEY = "rss_2.0.feed.ModuleParser.classes";

    /**
     * rss_2.0.item.ModuleParser.classes= [className] ...
     *
     */
    public static final String ITEM_MODULE_PARSERS_KEY = "rss_2.0.item.ModuleParser.classes";

    private static ModuleParsers FEED_MODULES_PARSER = new ModuleParsers(FEED_MODULE_PARSERS_KEY);
    private static ModuleParsers ITEM_MODULES_PARSER = new ModuleParsers(ITEM_MODULE_PARSERS_KEY);

    public RSS20Parser() {
        this("rss_2.0");
    }

    protected RSS20Parser(String type) {
        super(type);
    }

    protected String getRSSVersion() {
            return "2.0";
    }

    protected boolean isHourFormat24(Element rssRoot) {
        return false;
    }

    protected WireFeed parseChannel(Element rssRoot)  {
        Channel channel = (Channel) super.parseChannel(rssRoot);
        List modules = FEED_MODULES_PARSER.parseModules(rssRoot.getChild("channel",getRSSNamespace()));
        if (modules!=null) {
            channel.setModules(modules);
        }
        return channel;
    }

    protected Item parseItem(Element rssRoot,Element eItem) {
        Item item = super.parseItem(rssRoot,eItem);
        List modules = ITEM_MODULES_PARSER.parseModules(eItem);
        if (modules!=null) {
            item.setModules(modules);
        }
        return item;
    }


    protected Description parseItemDescription(Element rssRoot,Element eDesc) {
        Description desc = super.parseItemDescription(rssRoot,eDesc);
        desc.setType("text/plain"); // JDOM unescapes it, not sure if it's always OK
        return desc;
    }

}
