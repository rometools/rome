/*
 * Created on Jun 24, 2004
 *
 */
package com.sun.syndication.unittest;

/**
 * @author pat
 *
 */
public class TestSyndFeedRSS20 extends SyndFeedTest {

	public TestSyndFeedRSS20() {
		super("rss_2.0");
	}
}
