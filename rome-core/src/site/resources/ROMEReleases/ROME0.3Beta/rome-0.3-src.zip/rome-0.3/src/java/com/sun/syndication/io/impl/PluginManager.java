/*
 * Copyright 2004 Sun Microsystems, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
package com.sun.syndication.io.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Properties;
import java.util.Enumeration;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

/**
 * <p>
 * @author Alejandro Abdelnur
 *
 */
public abstract class PluginManager {
    private Map _pluginsMap;
    private List _pluginsList;
    private List _keys;

    /**
     * Creates a PluginManager
     * <p>
     * @param propertyKey property key defining the plugins classes
     *
     */
    protected PluginManager(String propertyKey) {
        loadPlugins(propertyKey);
        _pluginsMap = Collections.unmodifiableMap(_pluginsMap);
        _pluginsList = Collections.unmodifiableList(_pluginsList);
        _keys = Collections.unmodifiableList(new ArrayList(_pluginsMap.keySet()));
    }

    protected abstract String getKey(Object obj);


    protected List getKeys() {
        return _keys;
    }

    protected List getPlugins() {
        return _pluginsList;
    }

    protected Map getPluginMap() {
        return _pluginsMap;
    }

    protected Object getPlugin(String key) {
        return _pluginsMap.get(key);
    }

    // PRIVATE - LOADER PART

    private void loadPlugins(String key) {
        _pluginsList = new ArrayList();
        _pluginsMap = new HashMap();
        try {
            Class[] classes = getClasses(key);
            for (int i=0;i<classes.length;i++) {
                Object obj  = classes[i].newInstance();
                _pluginsList.add(obj);
                _pluginsMap.put(getKey(obj),obj);
            }
        }
        catch (Exception ex) {
            throw new RuntimeException("could not instanciate plugin ",ex);
        }
    }

    private static final String MASTER_PLUGIN_FILE = "com/sun/syndication/rome.properties";
    private static final String EXTRA_PLUGIN_FILE = "rome.properties";
    private static final Properties[] PLUGINS_DEFS;

    static {
        PLUGINS_DEFS = loadAllProperties();
    }

    private static Properties[] loadAllProperties() {
        ClassLoader classLoader = PluginManager.class.getClassLoader();
        List allProps = new ArrayList();

        try {
            // Rome own properties
            InputStream is = classLoader.getResourceAsStream(MASTER_PLUGIN_FILE);
            allProps.add(loadProperties(is));
        }
        catch (IOException ex) {
            throw new RuntimeException("could not load Rome plugins file",ex);
        }

        // Rome extensions properties, find them all
        try {
            Enumeration urls = classLoader.getResources(EXTRA_PLUGIN_FILE);
            while (urls.hasMoreElements()) {
                URL url = (URL) urls.nextElement();
                try {
                    InputStream is = url.openStream();
                    allProps.add(loadProperties(is));
                }
                catch (IOException ex) {
                    throw new RuntimeException("could not load Rome extensions plugins file ["+url.toString()+"] ",ex);
                }
            }
        }
        catch (IOException ex) {
            throw new RuntimeException("could not load fetch resources for Rome extensions plugins");
        }

        Properties[] array = new Properties[allProps.size()];
        allProps.toArray(array);
        return array;
    }

    private static Properties loadProperties(InputStream is) throws IOException {
        Properties props = new Properties();
        props.load(is);
        return props;
    }

    private static List parseAndLoadClasses(String classNames) throws ClassNotFoundException {
        ClassLoader classLoader = PluginManager.class.getClassLoader();
        List classes = new ArrayList();
        StringTokenizer st = new StringTokenizer(classNames,", ");
        while (st.hasMoreTokens()) {
            String className = st.nextToken();
            Class mClass = classLoader.loadClass(className);
            classes.add(mClass);
        }
        return classes;
    }

    /**
     * Loads and returns the classes defined in the properties files.
     * <p>
     * @param pluginKey property key defining the plugin classes.
     * @return array containing the classes defined in the properties files.
     * @throws java.lang.ClassNotFoundException thrown if one of the classes defined in the properties file cannot be loaded
     *         and hard failure is ON.
     *
     */
    private static Class[] getClasses(String pluginKey) throws ClassNotFoundException {
        List classes = new ArrayList();
        for (int i=0;i<PLUGINS_DEFS.length;i++) {
            String classNames = PLUGINS_DEFS[i].getProperty(pluginKey);
            if (classNames!=null) {
                classes.addAll(parseAndLoadClasses(classNames));
            }
        }
        Class[] array = new Class[classes.size()];
        classes.toArray(array);
        return array;
    }



}
