/*
 * Created on Jun 24, 2004
 *
 */
package com.sun.syndication.unittest;

/**
 * @author pat
 *
 */
public class TestSyndFeedRSS090 extends SyndFeedTest {

    public TestSyndFeedRSS090() {
        super("rss_0.9");
    }

}
