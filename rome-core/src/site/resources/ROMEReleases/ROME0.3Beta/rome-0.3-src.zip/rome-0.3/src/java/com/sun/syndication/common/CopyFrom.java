package com.sun.syndication.common;

/**
 * @author Alejandro Abdelnur
 */
public interface CopyFrom {

    /**
     * Returns the interface the copyFrom works on.
     * <p>
     * This is useful when dealing with properties that may have multiple implementations.
     * For example, ModuleI.
     * <p>
     * @return the interface the copyFrom works on.
     */
    public Class getInterface();

    /**
     * Copies all the properties of the given bean into this one.
     * <p>
     * Any existing properties in this bean are lost.
     * <p>
     * This method is useful for moving from one implementation of a bean interface to another.
     * For example from the default SyndFeedI bean implementation to a Hibernate ready implementation.
     * <p>
     * @param obj the instance to copy properties from.
     *
     */
    public void copyFrom(Object obj);

}
