/*
 * Created on Jun 24, 2004
 *
 */
package com.sun.syndication.unittest;

/**
 * @author pat
 *
 */
public class TestSyndFeedRSS094 extends SyndFeedTest {

	public TestSyndFeedRSS094() {
		super("rss_0.94");
	}
}
