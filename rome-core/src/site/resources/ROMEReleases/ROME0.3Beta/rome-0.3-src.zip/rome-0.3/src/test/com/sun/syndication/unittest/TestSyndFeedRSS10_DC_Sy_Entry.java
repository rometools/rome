/*
 * Created on Jun 25, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package com.sun.syndication.unittest;

import java.util.List;

import com.sun.syndication.feed.module.DCModuleI;
import com.sun.syndication.feed.synd.SyndEntryI;

/**
 * @author pat
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class TestSyndFeedRSS10_DC_Sy_Entry extends SyndFeedRSS10_DC_Sy_CommonTest {

    public TestSyndFeedRSS10_DC_Sy_Entry() {
        super("channel.item[0]");
    }

    protected DCModuleI getDCModule() throws Exception {
        List entryList = getCachedSyndFeed().getEntries();
        SyndEntryI entry = (SyndEntryI) entryList.get(0);
        return (DCModuleI) entry.getModule(DCModuleI.URI);
    }

}
