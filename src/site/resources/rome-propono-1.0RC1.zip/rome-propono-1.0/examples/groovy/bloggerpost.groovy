/*
Shows how to interact with Google's Blogger.com service.
*/

import com.sun.syndication.propono.atom.client.*;
import com.sun.syndication.feed.atom.*;

String email = "YOUR_EMAIL@gmail.com";
String password = "YOUR_PASSWORD";
String collectionURI = "http://www.blogger.com/feeds/YOUR_BLOGID/posts/default";
String atomServiceURI= "http://www.blogger.com/feeds/default/blogs?alt=atom-service";

ClientCollection col = 
    AtomClientFactory.getGDataCollection(collectionURI, email, password, "blogger");

// list most recent 20 posts
int count = 0;
for (Iterator it = col.getEntries(); it.hasNext();) {
    ClientEntry entry = (ClientEntry) it.next();
    println entry.title;
    if (count++ > 20) break;
}

// post a test entry
ClientEntry entry = col.createEntry();
Content content = new Content();
content.setValue("This is content from ROME Propono");
entry.setTitle("Propono post");
entry.setContent(content);
col.addEntry(entry);
