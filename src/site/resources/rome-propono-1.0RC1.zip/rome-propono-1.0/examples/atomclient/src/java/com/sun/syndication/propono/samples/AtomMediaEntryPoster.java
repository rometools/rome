/*
 * Copyright 2007 Sun Microsystems, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.sun.syndication.propono.samples;

import com.sun.syndication.propono.atom.client.AtomClientFactory;
import com.sun.syndication.propono.atom.client.BasicAuthStrategy;
import com.sun.syndication.propono.atom.client.ClientAtomService;
import com.sun.syndication.propono.atom.client.ClientCollection;
import com.sun.syndication.propono.atom.client.ClientMediaEntry;
import com.sun.syndication.propono.atom.client.ClientWorkspace;
import java.io.FileInputStream;

/**
 * Simple Atom client posts media entry given username, password, slug, filepath text and URI.
 */
public class AtomMediaEntryPoster {
    
    public static void main(String[] args) throws Exception {               
        if (args.length < 5) {
            System.out.println("USAGE: gifposter <username> <password> <slug> <filepath> <uri>");
            System.exit(-1);
        }
        String username = args[0];
        String password = args[1];
        String slug     = args[2];
        String filepath = args[3];
        String uri      = args[4];
        
        // Connect to service, GET Service Doc.
        ClientAtomService service = 
            AtomClientFactory.getAtomService(uri, new BasicAuthStrategy(username, password));
 
        // Find workspace by name
        ClientWorkspace workspace = (ClientWorkspace)
            service.findWorkspace("Generic Atom Handler Workspace");

        // Find first collection in workspace that will accept a GIF
        ClientCollection collection = (ClientCollection)
            workspace.findCollection(null, "image/gif");    
        
        // Create entry, set title and content but don't POST it yet
        ClientMediaEntry entry = collection.createMediaEntry(
            slug, slug, "image/gif", new FileInputStream(filepath)); 
        
        // POST entry to collection on server
        collection.addEntry(entry);
    }
}
