package com.sun.syndication.unittest;

/**
 *
 * <p>
 * @author Alejandro Abdelnur
 *
 */
public class TestOpsRSS092 extends FeedOpsTest {

    public TestOpsRSS092() {
        super("rss_0.92");
    }

}
