/*
 * Copyright 2004 Sun Microsystems, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
package com.sun.syndication.samples;

import com.sun.syndication.feed.synd.SyndFeed;
import com.sun.syndication.feed.synd.SyndFeedI;
import com.sun.syndication.io.SyndFeedInput;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.net.URLConnection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * It Reads and prints any RSS/Atom feed type.
 * <p>
 * @author Alejandro Abdelnur
 *
 */
public class FeedCopyFrom {

    public static void main(String[] args) {
        boolean ok = false;
        if (args.length==1) {
            try {
                URL feedUrl = new URL(args[0]);
                SyndFeedInput input = new SyndFeedInput();

                SyndFeedI feed1 = input.build(getFeedReader(feedUrl));
                feed1.setEncoding("UTF-8");
                SyndFeedI feedA = input.build(getFeedReader(feedUrl));

//                System.out.println("1=a "+feed1.equals(feedA));

//                System.out.println(feed1);
//                System.out.println(feedA);

                SyndFeedI feed2 = new SyndFeed();
                feed2.copyFrom(feed1);
//                System.out.println(feed2);

                SyndFeedI feed3 = new SyndFeed();;
                feed3.copyFrom(feed2);

                System.out.println(feed3);

                System.out.println("1=2 "+feed1.equals(feed2));
                System.out.println("1=3 "+feed1.equals(feed3));
                System.out.println("2=3 "+feed2.equals(feed3));

                ok = true;
            }
            catch (Exception ex) {
                ex.printStackTrace();
                System.out.println("ERROR: "+ex.getMessage());
            }
        }

        if (!ok) {
            System.out.println();
            System.out.println("FeedReader reads and prints any RSS/Atom feed type.");
            System.out.println("The first parameter must be the URL of the feed to read.");
            System.out.println();
        }
    }

    // To handle charset encoding of incoming feed properly


    private static final Pattern CHARSET_PATTERN = Pattern.compile("charset=([.[^; ]]*)");

    private static Reader getFeedReader(URL feedUrl) throws IOException {
        Reader reader;
        URLConnection conn = feedUrl.openConnection();

        if (feedUrl.getProtocol().equals("http") || feedUrl.getProtocol().equals("https")) {
            // Finds out server charset encoding based on HTTP spec

            String contentTypeHeader = conn.getContentType();
            String encoding = "ISO-8859-1";
            if (contentTypeHeader!=null) {
                Matcher matcher = CHARSET_PATTERN.matcher(contentTypeHeader);
                if (matcher.find()) {
                    encoding = matcher.group(1);
                }
            }
            reader = new InputStreamReader(conn.getInputStream(),encoding);
        }
        else {
            // Goes with plartform's default charset encoding

            reader = new InputStreamReader(conn.getInputStream());
        }
        return reader;
    }

}
