/*
 * Copyright 2004 Sun Microsystems, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
package com.sun.syndication.samples.module;

import com.sun.syndication.feed.module.ModuleI;
import com.sun.syndication.common.CopyFrom;

import java.util.List;
import java.util.Date;

/**
 * Sample Module Interface.
 * <p>
 * To show how to integrate a module in Rome.
 * <p>
 * @author Alejandro Abdelnur
 */
public interface SampleModuleI extends ModuleI,CopyFrom {

    /**
     * URI of the Sample Module (http://rome.dev.java.net/module/foo/1.0).
     *
     */
    String URI = "http://rome.dev.java.net/module/sample/1.0";

    /**
     * Returns the Sample module bar value.
     * @return the bar value.
     */
    String getBar();

    /**
     * Sets the Sample module bar value.
     * <p>
     * @param bar the bar value, <b>null</b> if none.
     *
     */
    void setBar(String bar);


    /**
     * Returns the Sample module foos.
     * <p>
     * @return a list of String elements with the Sample module foos,
     *         an empty list if none.
     *
     */
    List getFoos();

    /**
     * Sets the Sample module foos.
     * <p>
     * @param foos the list of String elements with the Sample module foos to set,
     *        an empty list or <b>null</b> if none.
     *
     */
    void setFoos(List foos);


    /**
     * Returns the Sample module date.
     * <p>
     * @return the Sample module date, <b>null</b> if none.
     *
     */
    Date getDate();

    /**
     * Sets the Sample module date.
     * <p>
     * @param date the Sample module date to set, <b>null</b> if none.
     *
     */
    void setDate(Date date);


}
