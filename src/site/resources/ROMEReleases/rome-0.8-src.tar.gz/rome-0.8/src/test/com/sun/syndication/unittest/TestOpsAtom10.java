package com.sun.syndication.unittest;

/**
 *
 * <p>
 * @author Dave Johnson
 *
 */
public class TestOpsAtom10 extends FeedOpsTest {

    public TestOpsAtom10() {
        super("atom_1.0");
    }

}
