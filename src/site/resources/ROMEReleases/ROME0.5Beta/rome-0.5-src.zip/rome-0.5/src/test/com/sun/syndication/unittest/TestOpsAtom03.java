package com.sun.syndication.unittest;

/**
 *
 * <p>
 * @author Alejandro Abdelnur
 *
 */
public class TestOpsAtom03 extends FeedOpsTest {

    public TestOpsAtom03() {
        super("atom_0.3");
    }

}
