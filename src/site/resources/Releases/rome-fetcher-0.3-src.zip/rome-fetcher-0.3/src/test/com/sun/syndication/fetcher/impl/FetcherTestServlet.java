/*
 * Copyright 2004 Sun Microsystems, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
package com.sun.syndication.fetcher.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class FetcherTestServlet extends javax.servlet.http.HttpServlet {

	/**
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		if ("TRUE".equalsIgnoreCase(request.getParameter("redirect"))) {
			//	testing redirection support			
			response.sendRedirect(request.getRequestURI());
			return;
		} else if (request.getParameter("error") != null) {
			//response.sendError(HttpServletResponse.SC_NOT_FOUND);	
			int errorToThrow = Integer.parseInt(request.getParameter("error"));
			response.sendError(errorToThrow);
			return;
		} else {
			
			// We manually set the date headers using strings
			// instead of the get/setDateHeader methods because
			// those methods return longs, which has too much
			// precision for the real date headers
			// this is just a random date
			String lastModifiedDate = "Thu, 08 Jan 2009 23:06:39 GMT"; 
			String eTag = "123456";
			
			if ("TRUE".equalsIgnoreCase(request.getParameter("refreshfeed"))) {
				lastModifiedDate = "Fri, 09 Jan 2009 12:06:39 GMT";
				eTag = "abcde"; 
			}
			
			boolean serveFeed = checkModified(request, lastModifiedDate, eTag);
			
			if (serveFeed) {
				sendFeedData(response, lastModifiedDate, eTag);
				return;					
			} else {
				response.sendError(HttpServletResponse.SC_NOT_MODIFIED);
				return;							
			}
		}							
	}

	private boolean checkModified(HttpServletRequest request, String lastModifiedDate, String eTag) {
		
		String requestedETag = request.getHeader("If-None-Match");			
		String requestedLastModified = request.getHeader("If-Modified-Since");
		boolean modified = true;
		boolean mustServer = false;			
		if (requestedETag != null) {
			if (eTag.equals(requestedETag)) {
				modified = false;
			} else {
				modified = true;
				mustServer = true;				
			}
		}
		if (requestedLastModified != null) {
			if (lastModifiedDate.equals(requestedLastModified)) {
				modified = false;
			} else {
				modified = true;
				mustServer = true;					
			}
		}
		boolean serveFeed = (modified || mustServer);
		return serveFeed;
	}

	private void sendFeedData(HttpServletResponse response, String lastModifiedDate, String eTag) throws IOException {
		response.setContentType("text/xml");
		if (eTag != null) {
			response.setHeader("ETag", eTag);
		}		
		if (lastModifiedDate != null) {
			response.setHeader("Last-Modified", lastModifiedDate);
		}
		
		InputStream inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream("/atom_0.3.xml");
		if (inputStream == null) {
		    inputStream = this.getClass().getResourceAsStream("/atom_0.3.xml");
		}
		
		BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
		try {
			String line;
			while ((line = reader.readLine()) != null) {									
				//response.getWriter().println(line);
			    response.getOutputStream().write(line.getBytes());
				line = null;
			}
		} finally {
			if (reader != null) {
			    reader.close();
			}
		}
	}
}
