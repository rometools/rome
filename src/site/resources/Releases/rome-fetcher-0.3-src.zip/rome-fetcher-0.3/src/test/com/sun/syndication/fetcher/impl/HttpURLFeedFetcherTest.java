/*
 * Copyright 2004 Sun Microsystems, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
package com.sun.syndication.fetcher.impl;

import java.net.URL;

import junit.framework.TestCase;

import org.mortbay.http.HttpContext;
import org.mortbay.http.HttpListener;
import org.mortbay.http.HttpServer;
import org.mortbay.http.SocketListener;
import org.mortbay.jetty.servlet.ServletHandler;

import com.sun.syndication.feed.synd.SyndFeedI;
import com.sun.syndication.fetcher.FeedFetcherI;
import com.sun.syndication.fetcher.FetcherEvent;
import com.sun.syndication.fetcher.FetcherException;
import com.sun.syndication.fetcher.FetcherListener;
import com.sun.syndication.fetcher.impl.FeedFetcherCacheI;
import com.sun.syndication.fetcher.impl.HashMapFeedInfoCache;
import com.sun.syndication.fetcher.impl.HttpURLFeedFetcher;


public class HttpURLFeedFetcherTest extends TestCase {
	HttpServer server;
	
	public void testUserAgent() {
		FeedFetcherI feedFetcher = new HttpURLFeedFetcher();
		System.out.println(feedFetcher.getUserAgent());
		System.out.println(System.getProperty("rome.fetcher.version", "UNKNOWN"));
		assertEquals("Rome Client (http://rome.dev.java.net/) Ver: " + System.getProperty("rome.fetcher.version", "UNKNOWN"), feedFetcher.getUserAgent());
	}	
	
	public void testRetrieveFeed() {
		FeedFetcherI feedFetcher = new HttpURLFeedFetcher();
		try {
			SyndFeedI feed = feedFetcher.retrieveFeed(new URL("http://localhost:8080/rome/FetcherTestServlet/"));
			assertEquals("atom_0.3.feed.title", feed.getTitle());			
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.getMessage());
		}
	}
	
	/**
	 * Test getting a feed via a http 301 redirect
	 *
	 */
	public void testRetrieveRedirectedFeed() {
		FeedFetcherI feedFetcher = new HttpURLFeedFetcher();
		try {
			SyndFeedI feed = feedFetcher.retrieveFeed(new URL("http://localhost:8080/rome/FetcherTestServlet?redirect=TRUE"));
			assertEquals("atom_0.3.feed.title", feed.getTitle());
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.getMessage());
		}
	}
	
	/**
	 * Test getting a feed via a http 301 redirect
	 *
	 */
	public void testErrorHandling() {
		FeedFetcherI feedFetcher = new HttpURLFeedFetcher();
		try {
			SyndFeedI feed = feedFetcher.retrieveFeed(new URL("http://localhost:8080/rome/FetcherTestServlet?error=404"));
			fail("4xx error handling did not work correctly");			
		} catch (FetcherException e) {
			// expect this exception		
			assertEquals(404, e.getResponseCode());				
		} catch (Exception e) {			
			e.printStackTrace();
			fail(e.getMessage());
		}
		
		try {
			SyndFeedI feed = feedFetcher.retrieveFeed(new URL("http://localhost:8080/rome/FetcherTestServlet?error=500"));
			fail("5xx error handling did not work correctly");			
		} catch (FetcherException e) {
			// expect this exception
			assertEquals(500, e.getResponseCode());						
		} catch (Exception e) {			
			e.printStackTrace();
			fail(e.getMessage());
		}		
	}	
	
	
	/**
	 * Test events fired when there is no cache in use
	 *
	 */
	public void testFetchEvents() {
		FeedFetcherI feedFetcher = new HttpURLFeedFetcher();
		FetcherEventListenerImpl listener = new FetcherEventListenerImpl();
		feedFetcher.addFetcherEventListener(listener);
		try {
			SyndFeedI feed = feedFetcher.retrieveFeed(new URL("http://localhost:8080/rome/FetcherTestServlet/"));
			assertTrue(listener.polled);
			assertTrue(listener.retrieved);
			assertFalse(listener.unchanged);			
			listener.reset();
			
			// since there is no cache, the events fired should be exactly the same if
			// we re-retrieve the feed 
			feed = feedFetcher.retrieveFeed(new URL("http://localhost:8080/rome/FetcherTestServlet/"));
			assertTrue(listener.polled);
			assertTrue(listener.retrieved);
			assertFalse(listener.unchanged);			
			listener.reset();															
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.getMessage());
		}
	}	
	
	/**
	 * Test events fired when there is a cache in use
	 *
	 */
	public void testFetchEventsWithCache() {
		FeedFetcherCacheI feedInfoCache = new HashMapFeedInfoCache();
		FeedFetcherI feedFetcher = new HttpURLFeedFetcher(feedInfoCache);
		FetcherEventListenerImpl listener = new FetcherEventListenerImpl();
		feedFetcher.addFetcherEventListener(listener);
		try {
			SyndFeedI feed = feedFetcher.retrieveFeed(new URL("http://localhost:8080/rome/FetcherTestServlet/"));
			assertTrue(listener.polled);
			assertTrue(listener.retrieved);
			assertFalse(listener.unchanged);			
			listener.reset();
			
			// Since the feed is cached, the second request should not
			// actually retrieve the feed
			feed = feedFetcher.retrieveFeed(new URL("http://localhost:8080/rome/FetcherTestServlet/"));
			assertTrue(listener.polled);
			assertFalse(listener.retrieved);
			assertTrue(listener.unchanged);			
			listener.reset();				
			
			// now simulate getting the feed after it has changed
			feed = feedFetcher.retrieveFeed(new URL("http://localhost:8080/rome/FetcherTestServlet?refreshfeed=TRUE"));
			assertTrue(listener.polled);
			assertTrue(listener.retrieved);
			assertFalse(listener.unchanged);			
			listener.reset();														
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.getMessage());
		}
	}	
	
	/**
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		// Create the server
		if (server != null) {
			server.stop();
			server = null;
		}
		server = new HttpServer();		
      
		// Create a port listener
		SocketListener listener=new SocketListener();
		listener.setPort(8080);
		server.addListener(listener);		
		
		HttpContext context = new HttpContext();	
		context.setContextPath("/rome/*");
		server.addContext(context);
		
		
		ServletHandler servlets = new ServletHandler();
		context.addHandler(servlets);
		
		servlets.addServlet("FetcherTestServlet","/FetcherTestServlet/*","com.sun.syndication.fetcher.impl.FetcherTestServlet");

		server.start();
	}
	
	/**
	 * @see junit.framework.TestCase#tearDown()
	 */
	protected void tearDown() throws Exception {
		if (server != null) {
			server.stop();
			server.destroy();
			server = null;			
		}
	}

	class FetcherEventListenerImpl implements FetcherListener {
		boolean polled = false;
		boolean retrieved = false;
		boolean unchanged = false;
		
		public void reset() {
			polled = false;
			retrieved = false;
			unchanged = false;			
		}

		/**
		 * @see com.sun.syndication.fetcher.FetcherListener#fetcherEvent(com.sun.syndication.fetcher.FetcherEvent)
		 */
		public void fetcherEvent(FetcherEvent event) {
			String eventType = event.getEventType();
			if (FetcherEvent.EVENT_TYPE_FEED_POLLED.equals(eventType)) {
				System.err.println("\tEVENT: Feed Polled. URL = " + event.getUrl().toString());
				polled = true;				
			} else if (FetcherEvent.EVENT_TYPE_FEED_RETRIEVED.equals(eventType)) {
				System.err.println("\tEVENT: Feed Retrieved. URL = " + event.getUrl().toString());
				retrieved = true;				
			} else if (FetcherEvent.EVENT_TYPE_FEED_UNCHANGED.equals(eventType)) {
				System.err.println("\tEVENT: Feed Unchanged. URL = " + event.getUrl().toString());
				unchanged = true;				
			}			
		}
	}	

}
