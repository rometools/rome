/*
 * Copyright 2004 Sun Microsystems, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package com.sun.syndication.fetcher.impl;

import java.io.IOException;
import java.io.InputStream;
import java.net.URLConnection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

import com.sun.syndication.fetcher.FeedFetcherI;
import com.sun.syndication.fetcher.FetcherEvent;
import com.sun.syndication.fetcher.FetcherListener;


public abstract class AbstractFeedFetcher implements FeedFetcherI {
	private Set fetcherEventListeners;
	private String userAgent;
	
	public AbstractFeedFetcher() {
		fetcherEventListeners = Collections.synchronizedSet(new HashSet());
		String fetcherVersion = "UNKNOWN";
		
		Properties props = new Properties();
		String resourceName = "fetcher.properties";
		
		try {
			InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(resourceName);
			if (inputStream == null) {
			    inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(resourceName);
			}			
			if (inputStream != null) {
				props.load(inputStream);
				System.setProperties(props);				
				inputStream.close();
			} else {
				System.err.println("Could not find " + resourceName + " on classpath");
			}
		} catch (IOException e) {
			// do nothing
			System.err.println("Error reading " + resourceName + " from classpath: " + e.getMessage());
		}		
		
		
		userAgent =  DEFAULT_USER_AGENT + " Ver: " + System.getProperty("rome.fetcher.version", "UNKNOWN");
	}

	/**
	 * @return the User-Agent currently being sent to servers
	 */
	public String getUserAgent() {
		return userAgent;
	}

	/**
	 * @param string The User-Agent to sent to servers
	 */
	public void setUserAgent(String string) {
		userAgent = string;
	}

	/**
	 * @param eventType The event type to fire
	 * @param connection the current connection
	 */
	protected void fireEvent(String eventType, URLConnection connection) {
		FetcherEvent fetcherEvent = new FetcherEvent(this, connection.getURL(), eventType);
		synchronized(fetcherEventListeners) {
			Iterator iter = fetcherEventListeners.iterator();
			while ( iter.hasNext()) {
				FetcherListener fetcherEventListener = (FetcherListener) iter.next();
				fetcherEventListener.fetcherEvent(fetcherEvent);							
			}					
		}
	}

	/**
	 * @see com.sun.syndication.fetcher.FeedFetcherI#addFetcherEventListener(com.sun.syndication.fetcher.FetcherListener)
	 */
	public void addFetcherEventListener(FetcherListener listener) {
		if (listener != null) {
			fetcherEventListeners.add(listener);		
		}	
		
	}

	/**
	 * @see com.sun.syndication.fetcher.FeedFetcherI#removeFetcherPolledListener(com.sun.syndication.fetcher.FetcherListener)
	 */
	public void removeFetcherPolledListener(FetcherListener listener) {
		if (listener != null) {
			fetcherEventListeners.remove(listener);		
		}		
	}
	
	
}
