package com.sun.syndication.fetcher;

import java.net.URL;
import java.util.EventObject;

/**
 * @author nl
 *
 */
public class FetcherEvent extends EventObject {
	public static final String EVENT_TYPE_FEED_POLLED = "FEED_POLLED";
	public static final String EVENT_TYPE_FEED_RETRIEVED = "FEED_RETRIEVED";
	public static final String EVENT_TYPE_FEED_UNCHANGED = "FEED_UNCHANGED";
	
	private URL url;
	private String eventType;

	public FetcherEvent(Object source) {
		super(source);
	}

	public FetcherEvent(Object source, URL url, String eventType) {
		this(source);
		setUrl(url);
		setEventType(eventType);
	}
	
	/**
	 * @return Returns the url.
	 */
	public URL getUrl() {
		return url;
	}
	/**
	 * @param url The url to set.
	 */
	public void setUrl(URL url) {
		this.url = url;
	}
	/**
	 * @return Returns the eventType.
	 */
	public String getEventType() {
		return eventType;
	}
	/**
	 * @param eventType The eventType to set.
	 */
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
}
