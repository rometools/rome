#!/bin/bash
_CP=.
for i in lib/*.jar; do
   _CP="$_CP":"$i"
done
export _CP
java -classpath ${_CP} com.sun.syndication.propono.samples.AtomMediaEntryPoster $1 $2 $3 $4 $5
