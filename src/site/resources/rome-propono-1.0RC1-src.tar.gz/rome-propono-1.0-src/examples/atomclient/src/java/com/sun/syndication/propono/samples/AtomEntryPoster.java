/*
 * Copyright 2007 Sun Microsystems, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.sun.syndication.propono.samples;

import com.sun.syndication.feed.atom.Content;
import com.sun.syndication.propono.atom.client.AtomClientFactory;
import com.sun.syndication.propono.atom.client.BasicAuthStrategy;
import com.sun.syndication.propono.atom.client.ClientAtomService;
import com.sun.syndication.propono.atom.client.ClientCollection;
import com.sun.syndication.propono.atom.client.ClientEntry;
import com.sun.syndication.propono.atom.client.ClientWorkspace;
import java.util.List;

/**
 * Simple Atom client posts entry given username, password, title, HTML text and URI.
 */
public class AtomEntryPoster {
    
    public static void main(String[] args) throws Exception {               
        if (args.length < 5) {
            System.out.println("USAGE: entryposter <username> <password> <title> <htmltext> <uri>");
            System.exit(-1);
        }
        String username = args[0];
        String password = args[1];
        String title    = args[2];
        String htmltext = args[3];
        String uri      = args[4];
        
        // Connect to service, GET Service Doc.
        ClientAtomService service = 
            AtomClientFactory.getAtomService(uri, new BasicAuthStrategy(username, password));
 
        // Find first workspace
        ClientWorkspace workspace = null;
        List workspaces = service.getWorkspaces();
        if (workspaces.size() > 0) {
            workspace = (ClientWorkspace)workspaces.get(0);
        } else {
            System.out.println("No workspaces found");
            System.exit(-1);
        }

        // Find first collection in workspace that will accept entries
        ClientCollection collection = (ClientCollection)
            workspace.findCollection(null, "entry");    
        
        if (collection != null) {
            // Create entry, set title and content but don't POST it yet
            ClientEntry entry = collection.createEntry();
            entry.setTitle(title);
            entry.setContent(htmltext,Content.HTML);

            // POST entry to collection on server
            collection.addEntry(entry);   
            
        } else {
            System.out.println("No collection found that accepts entries");
            System.exit(-1);
        }        
    }
}
