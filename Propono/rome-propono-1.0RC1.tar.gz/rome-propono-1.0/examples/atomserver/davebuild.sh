pushd ../..
ant clean dist
cp dist/rome-propono-1.0/lib/rome-propono-1.0.jar lib
popd
ant clean dist
rm -rf ~/tomcat/webapps/sample-atomserver* ~/tomcat/work/*
cp dist/sample-atomserver.war ~/tomcat/webapps
restartcat

