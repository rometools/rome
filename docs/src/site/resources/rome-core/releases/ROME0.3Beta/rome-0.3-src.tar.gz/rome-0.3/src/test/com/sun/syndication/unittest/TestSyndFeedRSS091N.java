/*
 * Created on Jun 24, 2004
 *
 */
package com.sun.syndication.unittest;

/**
 * @author pat
 *
 */
public class TestSyndFeedRSS091N extends SyndFeedTest {

	public TestSyndFeedRSS091N() {
		super("rss_0.91", "rss_0.91N.xml");
	}
}
