/*
 * Created on Jun 24, 2004
 *
 */
package com.sun.syndication.unittest;

/**
 * @author pat
 *
 */
public class TestSyndFeedRSS10 extends SyndFeedTest {

	public TestSyndFeedRSS10() {
		super("rss_1.0");
	}
}
