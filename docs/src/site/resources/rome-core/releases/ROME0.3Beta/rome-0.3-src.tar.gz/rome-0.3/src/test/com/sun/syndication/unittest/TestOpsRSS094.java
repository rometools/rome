package com.sun.syndication.unittest;

/**
 *
 * <p>
 * @author Alejandro Abdelnur
 *
 */
public class TestOpsRSS094 extends FeedOpsTest {

    public TestOpsRSS094() {
        super("rss_0.94");
    }

}
