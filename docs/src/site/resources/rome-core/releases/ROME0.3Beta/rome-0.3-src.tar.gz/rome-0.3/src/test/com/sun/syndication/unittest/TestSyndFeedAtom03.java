/*
 * Created on Jun 24, 2004
 *
 */
package com.sun.syndication.unittest;

/**
 * @author pat
 *
 */
public class TestSyndFeedAtom03 extends SyndFeedTest {

	public TestSyndFeedAtom03() {
		super("atom_0.3");
	}
    
}
