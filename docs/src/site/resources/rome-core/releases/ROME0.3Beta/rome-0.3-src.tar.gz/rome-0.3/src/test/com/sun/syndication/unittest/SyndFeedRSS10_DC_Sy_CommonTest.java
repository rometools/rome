/*
 * Created on Jun 25, 2004
 *
 */
package com.sun.syndication.unittest;

import java.util.List;

import com.sun.syndication.feed.module.DCModuleI;
import com.sun.syndication.feed.module.DCSubjectI;

/**
 * @author pat
 *
 */

public abstract class SyndFeedRSS10_DC_Sy_CommonTest extends SyndFeedTest {
    private String _elementPrefix;

    protected SyndFeedRSS10_DC_Sy_CommonTest(String elementPrefix) {
        super("rss_1.0", "rss_1.0_DC_Sy.xml");
        _elementPrefix = elementPrefix;
    }

    protected String getPrefix() {
        return super.getPrefix()+"."+_elementPrefix;
    }
    
    protected abstract DCModuleI getDCModule() throws Exception;

    public void testFeedDCPresent() throws Exception {
        assertNotNull(getDCModule());
    }

    public void testFeedDCUri()  throws Exception {
        assertEquals("http://purl.org/dc/elements/1.1/", getDCModule().getUri());
    }

    public void testFeedDCTitle() throws Exception {
        assertEqualsStr("dc:title", getDCModule().getTitle());
    }

    public void testFeedDCCreator()  throws Exception {
        assertEqualsStr("dc:creator", getDCModule().getCreator());
    }

    public void testFeedDCSubject() throws Exception {
        List subjects = getDCModule().getSubjects();
        assertEquals(2, subjects.size());
        DCSubjectI subject = null;
        for (int i=0; i<subjects.size();i++) {
            subject = (DCSubjectI)subjects.get(i);
            assertEqualsStr("dc:subject[" + i +"]", subject.getValue());
            assertEqualsStr("dc:subject[" + i +"].taxo:topic^resource", subject.getTaxonomyUri());
        }
    }

}
