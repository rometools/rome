package com.sun.syndication.unittest;

/**
 *
 * <p>
 * @author Alejandro Abdelnur
 *
 */
public class TestOpsRSS091N extends FeedOpsTest {

    public TestOpsRSS091N() {
        super("rss_0.91N");
    }

}
