package com.sun.syndication.unittest;

import com.sun.syndication.feed.rss.Content;
import com.sun.syndication.feed.rss.Channel;
import com.sun.syndication.feed.rss.Item;
import com.sun.syndication.io.WireFeedOutput;
import com.sun.syndication.io.WireFeedInput;
import junit.framework.TestCase;

import java.io.Writer;
import java.io.StringWriter;
import java.io.Reader;
import java.io.StringReader;

public class TestRss20 extends TestCase {

    private String createFeed() throws Exception {
        Channel channel = new Channel();
        channel.setLink("");
        channel.setTitle("");
        channel.setFeedType("rss_2.0");
        channel.setDescription("");
        Item item = new Item();
        Content content = new Content();
        content.setType("text/plain");
        content.setValue("hello");
        item.setContent(content);
        channel.getItems().add(item);

        StringWriter sw = new StringWriter();
        WireFeedOutput output = new WireFeedOutput();
        output.output(channel, sw);
        sw.close();

        return sw.toString();
    }

    public void testWrite() throws Exception {
        String s = createFeed();
        int hellos = 0;
        while (s.contains("hello")) {
            hellos++;
            s = s.substring(s.indexOf("hello") + "hello".length());
        }
        assertEquals(1, hellos); // if content:encoded is more than one this should fail
    }

    public void testRead() throws Exception {
        Reader r = new StringReader(createFeed());
        WireFeedInput input = new WireFeedInput();
        Channel ch = (Channel) input.build(r);
    }

    public void testReadWrite() throws Exception {
        Reader r = new StringReader(createFeed());
        WireFeedInput input = new WireFeedInput();
        Channel channel = (Channel) input.build(r);
        StringWriter sw = new StringWriter();
        WireFeedOutput output = new WireFeedOutput();
        output.output(channel, sw);
        sw.close();
        r = new StringReader(sw.toString());
        channel = (Channel) input.build(r);
        sw = new StringWriter();
        output.output(channel, sw);
        sw.close();
        System.out.println(sw);
    }

}
