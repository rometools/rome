/*
 * Created on Jun 24, 2004
 *
 */
package com.sun.syndication.unittest;

/**
 * @author pat
 *
 */
public class TestSyndFeedRSS20 extends TestSyndFeedRSS094 {

	public TestSyndFeedRSS20() {
		super("rss_2.0");
	}

    protected TestSyndFeedRSS20(String type) {
        super(type);
    }

    protected TestSyndFeedRSS20(String feedType,String feedFileName) {
        super(feedType,feedFileName);
    }

}
