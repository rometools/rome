
The Ant 'get-deps' will fetch the required jars and place them here.

If you delete the ROME jar then deps will be re-downloaded next time you build.
