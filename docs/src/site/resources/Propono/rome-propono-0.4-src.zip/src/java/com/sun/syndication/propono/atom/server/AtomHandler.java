/*
 * Copyright 2007 Apache Software Foundation
 * 
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  The ASF licenses this file to You
 * under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.  For additional information regarding
 * copyright in this work, please see the NOTICE file in the top level
 * directory of this distribution.
 */
package com.sun.syndication.propono.atom.server;

import java.io.InputStream;
import com.sun.syndication.feed.atom.Entry;
import com.sun.syndication.feed.atom.Feed;
import com.sun.syndication.propono.atom.common.AtomService;

/**
 * Interface for handling single Atom protocol requests.
 *
 * <p>To create your own Atom protocol implementation you must implement this 
 * interface and create a concrete sub-class of 
 * {@link com.sun.syndication.propono.atom.server.AtomHandlerFactory}
 * which is capable of instantiating it.</p>
 */
public interface AtomHandler
{
    /** 
     * Get username of authenticated user. Return the username of the
     * authenticated user 
     */
    public String getAuthenticatedUsername();

    /**
     * Return 
     * {@link com.sun.syndication.propono.atom.common.AtomService} 
     * object that contains the 
     * {@link com.sun.syndication.propono.atom.common.Workspace} objects 
     * available to the currently authenticated user and within those the 
     * {@link com.sun.syndication.propono.atom.common.Collection} avalaible.
     */
    public AtomService getIntrospection() throws AtomException;

    /**
     * Return collection or portion of collection specified by pathInfo.
     * @param pathInfo Used to determine which collection and range
     */
    public Feed getCollection(String[] pathInfo) throws AtomException;

    /**
     * Store new entry in collection specified by pathInfo and return 
     * representation of entry as it is stored on server.
     * @param pathInfo Path info portion of URL
     */
    public Entry postEntry(String[] pathInfo, Entry entry) throws AtomException;

    /**
     * Get entry specified by pathInfo.
     * @param pathInfo Path info portion of URL
     */
    public Entry getEntry(String[] pathInfo) throws AtomException;

    /**
     * Update entry specified by pathInfo and return new entry as represented
     * on the server.
     * @param pathInfo Path info portion of URL
     */
    public Entry putEntry(String[] pathInfo, Entry entry) throws AtomException;


    /**
     * Delete entry specified by pathInfo.
     * @param pathInfo Path info portion of URL
     */
    public void deleteEntry(String[] pathInfo) throws AtomException;

    /**
     * Store media data in collection specified by pathInfo, create an Atom
     * media-link entry to store metadata for the new media file and return 
     * that entry to the caller.
     */
    public Entry postMedia(
        String[] pathInfo, String title, String slug, String contentType, InputStream is) throws AtomException;

    /**
     * Update the media file part of a media-link entry.
     * @param pathInfo Path info portion of URL
     */
    public Entry putMedia(
        String[] pathInfo, String contentType, InputStream is) throws AtomException;

    /**
     * Return true if specified pathinfo represents URI of server's Service Document.
     */
    public boolean isIntrospectionURI(String [] pathInfo);

    /**
     * Return true if specified pathinfo represents URI of a collection.
     */
    public boolean isCollectionURI(String [] pathInfo);

    /**
     * Return true if specified pathinfo represents URI of an Atom entry.
     */
    public boolean isEntryURI(String[] pathInfo);

    /**
     * Return true if specified pathinfo represents media-edit URI.
     */
    public boolean isMediaEditURI(String[] pathInfo);
}

